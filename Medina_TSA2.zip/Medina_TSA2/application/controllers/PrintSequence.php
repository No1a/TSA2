<?php

class PrintSequence extends CI_Controller {
        
    function index(){
        echo $this->config->site_url();
        echo "<br \>";
        echo $this->config->base_url();
        echo "<br \>";
        echo $this->config->system_url();
        echo "<br \>";
        }

    function RegistrationPage(){
        $this->load->view('RegistrationPage');
    }

    function LoginPage(){
        $this->load->view('LoginPage');
    }

    function UserForm(){
        $this->load->view('UserForm');
    }

    
    }

    
?>