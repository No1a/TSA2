<?php
class Form extends CI_Controller {

public function index()
        {
                $this->load->helper(array('form', 'url'));
                $this->load->library('form_validation');
                $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
                $this->form_validation->set_rules('firstname', 'Firstname', 'required|alpha',
                array(
                    'required' => 'You must provide a %s.',
                    'alpha' => 'The field can only contain alphabetical characters.'
                )
                );
                $this->form_validation->set_rules('middlename', 'Middlename', 'required|alpha',
                array(
                    'required' => 'You must provide a %s.',
                    'alpha' => 'The field can only contain alphabetical characters.'
                )
                );
                $this->form_validation->set_rules('lastname', 'Lastname', 'required|alpha',
                array(
                    'required' => 'You must provide a %s.',
                    'alpha' => 'The field can only contain alphabetical characters.'
                )
                );
                $this->form_validation->set_rules('username', 'Username', 'required|alpha_numeric|min_length[6]|',
                array(
                    'required' => 'You must provide a %s.',
                    'alpha_numeric' => 'The field can only contain alpha-numeric characters.',
                    'min_length' => '{field} must have at least {param} characters.'
                )
                );
                $this->form_validation->set_rules('password', 'Password', 'required|min_length[8]',
                        array(
                                'required' => 'You must provide a %s.',
                                'min_length' => '{field} must have at least {param} characters.'
                            )
                );
                $this->form_validation->set_rules('conpassword', 'Confirm Password', 'required|min_length[8]|matches[password]',
                        array(
                                'required' => 'You must provide a %s.',
                                'min_length' => '{field} must have at least {param} characters.',
                                'matches' => 'Password do not match.'

                            )
                );
                $this->form_validation->set_rules('birthday', 'Birthday', 'required',
                        array(
                                'required' => 'You must provide a %s.',
                            )
                );
                $this->form_validation->set_rules('emailaddress', 'Emailaddress', 'required|valid_email',
                        array(
                                'required' => 'You must provide a %s.',
                                'valid_email' => 'Not a valid email format'
                            )
                );
                $this->form_validation->set_rules('contact', 'Contact', 'required|numeric',
                        array(
                                'required' => 'You must provide a %s.',
                                'numeric' => 'Field can only contain numbers'
                            )
                );

                if ($this->form_validation->run() == FALSE)
                {
                        $this->load->view('RegistrationPage');
                }
                else
                {
                        $this->load->view('UserForm');
                }
        }
    }
        ?>
