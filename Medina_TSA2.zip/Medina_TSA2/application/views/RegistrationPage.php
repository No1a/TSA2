<!DOCTYPE html>
<html>
<head>
<title>Registration Page</title>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <style>

/* CSS for header */
.header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #f5f5f5;
    }

    .header .logo {
      font-size: 25px;
      font-family: 'Sriracha', cursive;
      color: #000;
      text-decoration: none;
      margin-left: 30px;
    }

    .nav-items {
      display: flex;
      justify-content: space-around;
      align-items: center;
      background-color: #f5f5f5;
      margin-right: 20px;
    }

    .nav-items a {
      text-decoration: none;
      color: #000;
      padding: 35px 20px;
    }
/* CSS for button */
      .button {
        background-color: #00A9A5;
        color: white;
        padding: 10px 32px;
        text-align: center;
        font-size: 16px;
        cursor: pointer;
        border-radius: 30px;
        border-color: white;
        margin-left: auto;
        margin-right: auto;
      }
    </style>
</head>
<body>

<!-- header -->
<header class="header">
    <a href="#" class="logo">WebFLIX</a>
    <nav class="nav-items">
      <a href="<?= base_url('welcome');?>">Home</a>
      <a href="<?= base_url('form');?>">Login</a>
      <a href="<?= base_url('form');?>">Sign In</a>
    </nav>
  </header>

<!-- Registration Form -->
<?php echo form_open('form'); ?>
<div class="d-flex align-items-center justify-content-center mt-5 mb-5" style="min-height:700px;">
	<div class="col-md-6">
    <div class="card" style = "box-shadow: 1px 5px 5px black;">
			<div class="card-header">New User Registration</div>
			<div class="card-body">
				<form method="POST" enctype="multipart/form-data">
          <div class="mb-3">
						<label class="form-label">First Name</label>
            <input type="text" name="firstname" class="form-control" id="first_name" value="" />
            <?php echo form_error('firstname'); ?>
          </div>
          <div class="mb-3">
						<label class="form-label">Middle Name</label>
            <input type="text" name="middlename" class="form-control" id="middle_name" value="" />
            <?php echo form_error('middlename'); ?>
          </div>
          <div class="mb-3">
						<label class="form-label">Last Name</label>
            <input type="text" name="lastname" class="form-control" id="last_name" value="" />
            <?php echo form_error('lastname'); ?>
          </div>
          <div class="mb-3">
						<label class="form-label">User Name</label>
            <input type="text" name="username" class="form-control" id="user_name" value="" />
            <?php echo form_error('username'); ?>
          </div>
          <div class="mb-3">
						<label class="form-label">Password</label>
						<input type="password" name="password" id="user_password" class="form-control" />
            <?php echo form_error('password'); ?>
					</div>
          <div class="mb-3">
						<label class="form-label">Confirm Password</label>
						<input type="password" name="conpassword" id="confirm_password" class="form-control" />
            <?php echo form_error('conpassword'); ?>
					</div>
          <div class="mb-3">
						<label class="form-label">Birthday</label>
						<input name="birthday" id="birthday" class="form-control" />
            <?php echo form_error('birthday'); ?>
					</div>
					<div class="mb-3">
						<label class="form-label">Email address</label>
						<input type="text" name="emailaddress" id="user_email_address" class="form-control" />
            <?php echo form_error('emailaddress'); ?>
					</div>
					<div class="mb-3">
						<label class="form-label">Contact No.</label>
						<input type="text" name="contact" id="user_contact_no" class="form-control" />
            <?php echo form_error('contact'); ?>
					</div>
					<div class="text-center mt-4 mb-2">
						<input type="submit" name="register_button" class="button" value="Register" />
					</div>
				</form>
			</div>
		</div>
  </div>
</div>

</body>
</html>
