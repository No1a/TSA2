<!DOCTYPE html>
<html>
<head>
<title>Login Page</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
    <style>

    /* CSS for header */
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #f5f5f5;
    }

    .header .logo {
      font-size: 25px;
      font-family: 'Sriracha', cursive;
      color: #000;
      text-decoration: none;
      margin-left: 30px;
    }

    .nav-items {
      display: flex;
      justify-content: space-around;
      align-items: center;
      background-color: #f5f5f5;
      margin-right: 20px;
    }

    .nav-items a {
      text-decoration: none;
      color: #000;
      padding: 35px 20px;
    }

    /* CSS for Button */
      .button {
        background-color: #00A9A5;
        color: white;
        padding: 10px 32px;
        text-align: center;
        font-size: 16px;
        cursor: pointer;
        border-radius: 30px;
        border-color: white;
        margin-left: auto;
        margin-right: auto;
      }
    </style>
</head>
<body>
<!-- header -->
<header class="header">
    <a href="#" class="logo">WebFLIX</a>
    <nav class="nav-items">
      <a href="<?= base_url('welcome');?>">Home</a>
      <a href="<?= base_url('regform');?>">Login</a>
      <a href="<?= base_url('form');?>">Sign In</a>
    </nav>
  </header>
 
<!-- Login Form -->
<?php echo form_open('regform'); ?>
<div class="d-flex align-items-center justify-content-center mt-5 mb-5" style="min-height:300px;">
  <div class="col-md-4">
        <div class="card" style = "box-shadow: 1px 5px 5px black;">
            <div class="card-header">User Login</div>
            <div class="card-body">
                <form method="POST">
                    <div class="mb-3">
                      <label class="form-label">User Name</label>
                      <input type="text" name="username" class="form-control" id="user_name" value="" />
                      <?php echo form_error('username'); ?>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" id="user_password" class="form-control" />
                        <?php echo form_error('password'); ?>
                    </div>
                    <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                        <input type="submit" name="login_button" class="button" value="Login" />
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

</body>
</html>
